const Sequelize = require('sequelize');
const path = require('path');

module.exports = new Sequelize({
    dialect: 'mysql',
    storage: path.join(__dirname, '../database/database.sql'),
});