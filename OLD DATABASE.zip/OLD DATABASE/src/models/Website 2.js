const { DataTypes, Deferrable } = require('sequelize');
const db = require('../config/db');

const Website = db.define('website', {
    ID: {
        type:DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false,
    },
    URL: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    securityFlag: {
        type: DataTypes.ENUM('value 0', 'value 1'),
        allowNull: false,
    },
    fromWhitelist:{
        type: DataTypes.ENUM('value 0', 'value 1'),
        allowNull: false,
    },
});

Website.sync();

module.exports = Website;