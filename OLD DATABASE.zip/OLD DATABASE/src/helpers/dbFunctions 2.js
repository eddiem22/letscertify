const sequelize = require('sequelize');
const fs = require('fs');
const { readdir } = require('fs/promises');
const path = require('path');


const Website = require('../models/Website.js');




const writeURLS = async () => {
    const URLArray = [];
    try
    {
    fqs.readFile('../config/file.txt', function(err, data) {
        if(err) throw err;
    
        const arr = data.toString().replace(/\r\n/g,'\n').split('\n');
    
        for(let i of arr) async() => {
            const website = await Website.findOne({
                where: { URL: i }
              });
              if(!website){
                  await Website.create({
                      URL: i,
                      securityFlag: '1',
                      fromWhitelist: '1',
                  });
              }
              URLArray.push([i, website.ID, website.securityFlag, website.fromWhitelist]);
        }
    });
} // end of try block
   catch(err) {
            console.error(err);
        }
        //end of catch block
        return URLArray;
    };
//end of initial URL database creation


////add website to DB
 const addWebsite = async (url) => {
     const type = await Website.findOne({where: {URL:url} } )
    if(!type){
        await Website.create({
            URL: i,
            securityFlag: '1',
            fromWhitelist: '1',
        });
    }
     
 }
////check if website is in DB
 const checkWebsite = async (url) => {}
  

 //delete website in DB
 const deleteWebsite = async (url) => {
    const type = await Website.findOne({where: {URL:url} } )
    await Website.destroy({where: {ID:type.ID} } )
}

module.exports = {
    writeURLS,
    addWebsite,
    deleteWebsite,
    checkWebsite,
};